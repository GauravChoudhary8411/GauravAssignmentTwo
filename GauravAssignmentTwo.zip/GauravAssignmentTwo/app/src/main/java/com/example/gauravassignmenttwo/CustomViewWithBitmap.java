package com.example.gauravassignmenttwo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

public class CustomViewWithBitmap extends View {
    Bitmap bg, mario, mario2;
    Paint p;
    int y = 1050, x = 350, x1 = 350, y1 = 1050;

    public CustomViewWithBitmap(Context context) {
        super(context);
        init();
    }

    void init() {
        p = new Paint();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        bg = BitmapFactory.decodeResource(getResources(), R.drawable.game_bg);
        Rect r1 = new Rect(0, 0, bg.getWidth(), bg.getHeight());
        Rect r2 = new Rect(0, 0, canvas.getWidth(), canvas.getHeight());
        canvas.drawBitmap(bg, r1, r2, null);
        mario = BitmapFactory.decodeResource(getResources(), R.drawable.small_mario2);
        mario2 = BitmapFactory.decodeResource(getResources(), R.drawable.small_mario1);
        canvas.drawBitmap(mario, x, y, null);
        canvas.drawBitmap(mario2, x1, y1, null);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                jump();
                moveAhead();
                break;
            case MotionEvent.ACTION_UP:
                down();
                break;
        }
        return true;
    }

    public void moveAhead() {
        if (x > 700 || x1 < -700) {
            x = 0;
            x1 = 700;
            down();
            invalidate();
        } else {
            x = x + 70;
            x1 = x1 - 70;
            invalidate();
        }
    }

    public void jump() {
        if (x > 700 || x1 < -700) {
            y += 100;
            y1 += 100;
            invalidate();
        }
    }

    public void down() {
        if (x > 700 || x1 < -700) {
            y -= 400;
            y1 -= 400;
            invalidate();
        }
    }
}

