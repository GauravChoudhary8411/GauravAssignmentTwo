package com.example.gauravassignmenttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class canvas extends AppCompatActivity {
    reset r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canvas);
        r=new reset(this);
        setContentView(r);
    }
}