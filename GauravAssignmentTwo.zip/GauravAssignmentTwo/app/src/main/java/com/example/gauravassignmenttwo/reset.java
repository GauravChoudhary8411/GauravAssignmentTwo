package com.example.gauravassignmenttwo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;
import android.graphics.Path;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;

public class reset extends View {
    Paint p;
    Path mpath;
    boolean b;
    Bitmap bitmap_light;
    Bitmap bitmap_dark;
    int draw_dark = R.drawable.ic_autorenew_black_24dp;
    int draw_light = R.drawable.ic_autorenew_black_lightdp;

    public reset(Context context) {
        super(context);
        p = new Paint();
        bitmap_light = getBitFromVector(context, draw_light);
        bitmap_dark = getBitFromVector(context, draw_dark);
        mpath = new Path();
        p.setColor(Color.BLACK);
        p.setStyle(Paint.Style.STROKE);
        //.FILL);
        p.setStrokeWidth(20f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.YELLOW);
        canvas.drawPath(mpath, p);
        if (b) {
            canvas.drawBitmap(bitmap_dark, 10, 10, p);
        } else {
            canvas.drawBitmap(bitmap_light, 10, 10, p);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mpath.moveTo(event.getX(), event.getY());// beginning point// set the beginning of the next contour to the point(x,y)
                break;
            case MotionEvent.ACTION_MOVE:
                b = true;
                mpath.lineTo(event.getX(), event.getY());//add a line from last point to specified point
                break;
            case MotionEvent.ACTION_UP:
                int x = (int) event.getX();
                int y = (int) event.getY();
                if ((x >= 10 & x <= 110) & (y >= 10 & y <= 120)) {
                    b = false;
                    mpath.reset();
                }
        }
        invalidate();
        return true;
    }


    public static Bitmap getBitFromVector(Context context, int drawableId) {
        Drawable drawable = ContextCompat.getDrawable(context, drawableId);

        drawable = (DrawableCompat.wrap(drawable)).mutate();

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, 80, 80);//canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);


        return bitmap;

    }


}
